IMPULSOS SUPPLY — BACKEND COM LOGIN ADMIN REAL (BASE PARA HOSPEDAGEM)

Este projeto já usa um servidor Node.js, banco SQLite, sessões de servidor e hash de senha. A área admin fica em /admin; a página pública fica em /.

IMPORTANTE: este pacote não foi publicado na internet. Para os clientes acessarem, você precisa hospedar o projeto em um serviço que suporte Node.js. Use HTTPS em produção.

REQUISITOS
- Node.js 20 ou superior
- npm

CONFIGURAÇÃO LOCAL
1. Extraia o ZIP e abra a pasta no terminal.
2. Execute: npm install
3. Copie .env.example para .env.
4. Crie uma senha forte e gere o hash:
   npm run hash-password -- "SuaSenhaForteComPeloMenos10Caracteres"
5. Cole o resultado do hash na variável ADMIN_PASSWORD_HASH do .env.
6. Defina ADMIN_USERNAME, e SESSION_SECRET como uma sequência aleatória com pelo menos 32 caracteres.
7. Para SESSION_SECRET, gere uma string aleatória longa e mantenha-a privada.
8. Execute: npm start
9. Abra http://localhost:3000 para a página pública e http://localhost:3000/admin para o painel privado.

HOSPEDAGEM
- Configure as variáveis do .env no painel de hospedagem; não envie o arquivo .env ao Git nem o publique.
- Use armazenamento persistente para data.sqlite e sessions.sqlite. Se o host não mantiver arquivos locais, troque SQLite por banco gerenciado.
- Configure NODE_ENV=production e HTTPS na hospedagem.
- Faça backup do banco e limite quem tem acesso ao painel da hospedagem.

O QUE FUNCIONA
- Admin com login no servidor e sessão HTTP-only.
- Produtos, preço, quantidade de impulsos e estoque.
- Geração de keys no servidor, validade opcional e uso único.
- Ativação pública de key com convite de servidor Discord.
- Consulta de status por key.
- Administração de pedidos.

LIMITAÇÕES
- Não há integração de pagamento com Discord/loja.
- Não há integração de entrega automática de impulsos. Os pedidos ficam como Pendente até você processar e mudar o status. Para automação real, conecte um provedor autorizado e compatível.
- Não coloque tokens, senhas, cookies ou credenciais de contas Discord no site.
- Faça testes e revisão de segurança antes de usar com clientes reais.


DEPLOY AUTOMÁTICO PREPARADO PARA RENDER (AINDA PRECISA DA SUA CONTA)
1. Crie um repositório Git privado e envie os arquivos deste projeto (não envie .env, senhas ou bancos).
2. Entre no Render e conecte o repositório.
3. Selecione o arquivo render.yaml (Blueprint). O Render criará o serviço e um disco persistente.
4. Quando pedir ADMIN_PASSWORD_HASH, gere localmente:
   npm install
   npm run hash-password -- "SuaSenhaForteComPeloMenos10Caracteres"
   Cole somente o hash gerado no campo ADMIN_PASSWORD_HASH.
5. Confirme o deploy. Após concluir, abra a URL fornecida pelo Render.
6. A página pública fica em / e o admin em /admin.
7. Troque ADMIN_USERNAME se quiser; mantenha as variáveis secretas fora do código.

OBSERVAÇÃO SOBRE CUSTO
O arquivo usa o plano Starter do Render para que o serviço e o disco persistente possam ficar online. Confira os preços e condições atuais na sua conta antes de confirmar. Não consigo criar a conta, aceitar cobranças ou publicar em nome do usuário sem acesso/autorização explícita.

AINDA FALTA PARA ENTREGA AUTOMÁTICA
O site valida e registra keys e pedidos, mas não aplica impulsos automaticamente. Para isso, é necessário escolher um provedor autorizado com API de entrega e configurar as credenciais secretas dele no servidor. Não envie tokens de usuário Discord; use somente credenciais oficiais do provedor/API autorizada.
