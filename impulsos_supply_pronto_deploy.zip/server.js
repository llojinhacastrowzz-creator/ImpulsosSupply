require('dotenv').config();
const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProd = process.env.NODE_ENV === 'production';
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  console.error('Configure SESSION_SECRET com pelo menos 32 caracteres no .env');
  process.exit(1);
}
if (!process.env.ADMIN_USERNAME || !process.env.ADMIN_PASSWORD_HASH) {
  console.error('Configure ADMIN_USERNAME e ADMIN_PASSWORD_HASH no .env');
  process.exit(1);
}
app.set('trust proxy', isProd ? 1 : false);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '30kb' }));
app.use(express.urlencoded({ extended: false, limit: '30kb' }));

const dataDir = process.env.DATA_DIR || (isProd ? '/app/data' : __dirname);\nconst fs = require('fs');\nfs.mkdirSync(dataDir, { recursive: true });\nconst db = new Database(process.env.DB_FILE || path.join(dataDir, 'data.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS products (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
 price_cents INTEGER NOT NULL, impulse_qty INTEGER NOT NULL, stock INTEGER NOT NULL DEFAULT 0,
 active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS keys (
 code TEXT PRIMARY KEY, product_id TEXT NOT NULL, expires_at TEXT, used_at TEXT,
 created_at TEXT NOT NULL, FOREIGN KEY(product_id) REFERENCES products(id)
);
CREATE TABLE IF NOT EXISTS orders (
 id TEXT PRIMARY KEY, key_code TEXT NOT NULL, product_id TEXT NOT NULL,
 invite TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Pendente', created_at TEXT NOT NULL,
 FOREIGN KEY(product_id) REFERENCES products(id)
);
`);
const iso = () => new Date().toISOString();
const sessionStore = new SQLiteStore({ db: 'sessions.sqlite', dir: dataDir });
app.use(session({
  name: 'impulsos.sid',
  secret: process.env.SESSION_SECRET,
  store: sessionStore,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: isProd, maxAge: 8 * 60 * 60 * 1000 }
}));
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: 'draft-7', legacyHeaders: false });
const redeemLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false });

function requireAdmin(req, res, next) {
  if (!req.session || req.session.admin !== true) return res.status(401).json({ error: 'Acesso restrito.' });
  next();
}
function safeProduct(p) {
  return { id:p.id, name:p.name, description:p.description, priceCents:p.price_cents,
    impulseQty:p.impulse_qty, stock:p.stock, active:!!p.active, createdAt:p.created_at };
}
function newKey() {
  const chunks = [4,4,4].map(n => crypto.randomBytes(n).toString('hex').toUpperCase());
  return 'IS-' + chunks.join('-');
}
app.get('/healthz', (req,res) => res.json({ ok: true }));\napp.use(express.static(path.join(__dirname, 'public')));
app.get('/api/products', (req,res) => {
  const products = db.prepare('SELECT * FROM products WHERE active=1 ORDER BY created_at DESC').all().map(safeProduct);
  res.json({ products });
});
app.post('/api/admin/login', loginLimiter, async (req,res) => {
  const { username, password } = req.body || {};
  if (typeof username !== 'string' || typeof password !== 'string') return res.status(400).json({error:'Informe usuário e senha.'});
  const okUser = crypto.timingSafeEqual(Buffer.from(username.padEnd(128).slice(0,128)), Buffer.from(String(process.env.ADMIN_USERNAME).padEnd(128).slice(0,128)));
  const okPass = await bcrypt.compare(password, process.env.ADMIN_PASSWORD_HASH);
  if (!okUser || !okPass) return res.status(401).json({error:'Usuário ou senha incorretos.'});
  req.session.regenerate(err => {
    if (err) return res.status(500).json({error:'Não foi possível iniciar a sessão.'});
    req.session.admin = true;
    res.json({ok:true});
  });
});
app.post('/api/admin/logout', requireAdmin, (req,res) => req.session.destroy(() => {
  res.clearCookie('impulsos.sid'); res.json({ok:true});
}));
app.get('/api/admin/me', requireAdmin, (req,res) => res.json({admin:true}));
app.get('/api/admin/products', requireAdmin, (req,res) => {
  res.json({products: db.prepare('SELECT * FROM products ORDER BY created_at DESC').all().map(safeProduct)});
});
app.post('/api/admin/products', requireAdmin, (req,res) => {
  const {name, description='', price, impulseQty, stock=0} = req.body || {};
  if (typeof name!=='string' || !name.trim() || name.length>100 || typeof description!=='string' || description.length>500 ||
      !Number.isFinite(Number(price)) || Number(price)<0 || !Number.isInteger(Number(impulseQty)) || Number(impulseQty)<1 ||
      !Number.isInteger(Number(stock)) || Number(stock)<0) return res.status(400).json({error:'Dados de produto inválidos.'});
  const id = crypto.randomUUID();
  db.prepare('INSERT INTO products(id,name,description,price_cents,impulse_qty,stock,created_at) VALUES(?,?,?,?,?,?,?)')
    .run(id,name.trim(),description.trim(),Math.round(Number(price)*100),Number(impulseQty),Number(stock),iso());
  res.json({product:safeProduct(db.prepare('SELECT * FROM products WHERE id=?').get(id))});
});
app.patch('/api/admin/products/:id', requireAdmin, (req,res) => {
  const p=db.prepare('SELECT * FROM products WHERE id=?').get(req.params.id);
  if(!p) return res.status(404).json({error:'Produto não encontrado.'});
  const {active,stock,name,description,price,impulseQty}=req.body||{};
  db.prepare(`UPDATE products SET active=?, stock=?, name=?, description=?, price_cents=?, impulse_qty=? WHERE id=?`)
    .run(active===undefined?p.active:(active?1:0),stock===undefined?p.stock:Number(stock),
      name===undefined?p.name:String(name).trim(),description===undefined?p.description:String(description).trim(),
      price===undefined?p.price_cents:Math.round(Number(price)*100),impulseQty===undefined?p.impulse_qty:Number(impulseQty),p.id);
  res.json({product:safeProduct(db.prepare('SELECT * FROM products WHERE id=?').get(p.id))});
});
app.delete('/api/admin/products/:id', requireAdmin, (req,res) => {
  db.prepare('UPDATE products SET active=0 WHERE id=?').run(req.params.id);
  res.json({ok:true});
});
app.post('/api/admin/keys', requireAdmin, (req,res) => {
  const {productId, count=1, expiryDays=null}=req.body||{};
  const product=db.prepare('SELECT * FROM products WHERE id=? AND active=1').get(productId);
  if(!product) return res.status(400).json({error:'Escolha um produto ativo.'});
  const n=Number(count), days=expiryDays===null?null:Number(expiryDays);
  if(!Number.isInteger(n)||n<1||n>100||!(days===null||(Number.isInteger(days)&&days>=1&&days<=365))) return res.status(400).json({error:'Quantidade/validade inválida.'});
  const insert=db.prepare('INSERT INTO keys(code,product_id,expires_at,created_at) VALUES(?,?,?,?)');
  const keys=[];
  const tx=db.transaction(()=>{
    for(let i=0;i<n;i++){const code=newKey();const expires=days===null?null:new Date(Date.now()+days*86400000).toISOString();insert.run(code,productId,expires,iso());keys.push({code,expiresAt:expires});}
  }); tx();
  res.json({keys});
});
app.get('/api/admin/keys', requireAdmin, (req,res) => {
  res.json({keys:db.prepare(`SELECT k.code,k.product_id AS productId,p.name AS productName,k.expires_at AS expiresAt,k.used_at AS usedAt,k.created_at AS createdAt FROM keys k LEFT JOIN products p ON p.id=k.product_id ORDER BY k.created_at DESC LIMIT 500`).all()});
});
app.get('/api/admin/orders', requireAdmin, (req,res) => {
  res.json({orders:db.prepare(`SELECT o.*,p.name AS product_name FROM orders o LEFT JOIN products p ON p.id=o.product_id ORDER BY o.created_at DESC LIMIT 500`).all()});
});
app.patch('/api/admin/orders/:id', requireAdmin, (req,res) => {
  const allowed=['Pendente','Em processamento','Concluído','Falhou'];
  if(!allowed.includes(req.body?.status)) return res.status(400).json({error:'Status inválido.'});
  const r=db.prepare('UPDATE orders SET status=? WHERE id=?').run(req.body.status,req.params.id);
  if(!r.changes) return res.status(404).json({error:'Pedido não encontrado.'});
  res.json({ok:true});
});
app.post('/api/redeem', redeemLimiter, (req,res) => {
  const code=String(req.body?.code||'').trim().toUpperCase();
  const invite=String(req.body?.invite||'').trim();
  if(!/^IS-[A-F0-9]{8}-[A-F0-9]{8}-[A-F0-9]{8}$/.test(code)) return res.status(400).json({error:'Formato de key inválido.'});
  let u; try { u=new URL(invite); } catch { return res.status(400).json({error:'Convite inválido.'}); }
  if(u.protocol!=='https:' || !['discord.gg','www.discord.gg','discord.com','www.discord.com'].includes(u.hostname) ||
    !(u.hostname.endsWith('discord.gg') || u.pathname.startsWith('/invite/'))) return res.status(400).json({error:'Use um convite HTTPS do Discord.'});
  const key=db.prepare('SELECT * FROM keys WHERE code=?').get(code);
  if(!key) return res.status(404).json({error:'Key inválida.'});
  if(key.used_at) return res.status(409).json({error:'Esta key já foi utilizada.'});
  if(key.expires_at && Date.now()>Date.parse(key.expires_at)) return res.status(410).json({error:'Esta key expirou.'});
  const product=db.prepare('SELECT * FROM products WHERE id=? AND active=1').get(key.product_id);
  if(!product) return res.status(400).json({error:'Este produto não está disponível.'});
  const orderId=crypto.randomUUID();
  const tx=db.transaction(()=>{
    const upd=db.prepare('UPDATE keys SET used_at=? WHERE code=? AND used_at IS NULL').run(iso(),code);
    if(!upd.changes) throw new Error('KEY_ALREADY_USED');
    db.prepare('INSERT INTO orders(id,key_code,product_id,invite,status,created_at) VALUES(?,?,?,?,?,?)')
      .run(orderId,code,product.id,invite,'Pendente',iso());
  });
  try { tx(); } catch(e) { return res.status(409).json({error:'Esta key já foi utilizada.'}); }
  res.json({ok:true,orderId,status:'Pendente',message:'Key validada e pedido registrado. A entrega ainda depende de integração autorizada.'});
});
app.get('/api/order-status/:code', (req,res) => {
  const code=String(req.params.code||'').trim().toUpperCase();
  const order=db.prepare('SELECT status,created_at AS createdAt FROM orders WHERE key_code=?').get(code);
  if(!order) return res.status(404).json({error:'Pedido não encontrado.'});
  res.json(order);
});
app.get('/admin', (req,res) => res.sendFile(path.join(__dirname,'public','admin.html')));
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:'Erro interno.'});});
app.listen(PORT,()=>console.log(`Impulsos Supply disponível na porta ${PORT}`));
