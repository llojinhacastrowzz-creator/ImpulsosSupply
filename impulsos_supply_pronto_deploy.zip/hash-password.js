const bcrypt=require('bcryptjs');
const p=process.argv[2];
if(!p || p.length<10){console.error('Use: npm run hash-password -- "SuaSenhaForteCom10Caracteres"');process.exit(1)}
bcrypt.hash(p,12).then(h=>console.log(h));
